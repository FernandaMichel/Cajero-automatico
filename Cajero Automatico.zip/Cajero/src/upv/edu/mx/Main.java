
package upv.edu.mx;
import java.util.Scanner;
public class Main {
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        int nip = 0;
        int c = 0;
        
        System.out.println("******* Cajero automatico *******");

        do{
        System.out.println("Leyendo tarjeta.....");
        System.out.println("Ingrese su NIP (4 digitos): ");
        nip = sc.nextInt();
        
        if(nip == 1981){
        //Si el nip es correcto, el usuario podra realizar movimientos    
        CAPadre cp = new CConsultas();
        cp.operaciones();
        }else{
            System.out.println("NIP incorrecto, inténtelo de nuevo");
            c+=1;
        }
        
        if(c == 3){
            //Si los intentos fallidos son igual a 3, se bloquea la tarjeta y termina la ejecucion
            System.out.println("*******************************************************************");
            System.out.println("Tarjeta bloqueada (Ingresó su NIP incorrectamente demasiadas veces)");
            System.out.println("*******************************************************************");
            System.exit(0);
        }
        
        }while(nip!=1981);

    }
}
