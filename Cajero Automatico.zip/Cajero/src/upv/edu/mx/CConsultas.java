
package upv.edu.mx;

public class CConsultas extends CAPadre{

    @Override
    public void movimiento() 
    {
        CDepositos cd = new CDepositos();
        CRetiros cr = new CRetiros();
        CServicios cs = new CServicios();
        CTransferencias ct = new CTransferencias();
        CDonaciones cdo = new CDonaciones();
        System.out.println("****************************");
        System.out.println("Saldo actual: " + "$"+getSaldo()+" pesos.");
        System.out.println("Movimientos: ");
        System.out.println("  -Retiros: " + cr.getRetiros());
        System.out.println("  -Depositos: " + cd.getDepositos());
        System.out.println("  -Servicios: " + cs.getServicios());
        System.out.println("  -Transferencias: " + ct.getTransferencias());
        System.out.println("  -Donaciones: " + cdo.getDonaciones());
        System.out.println("****************************");
    }

    
    
}
