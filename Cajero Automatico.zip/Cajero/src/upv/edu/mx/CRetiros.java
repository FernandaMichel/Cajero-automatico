
package upv.edu.mx;


public class CRetiros extends CAPadre {

    private static int retiros;
    
    @Override
    public void movimiento() 
    {
        int temp = 0;
        System.out.print("¿Cuanto desea retirar?: ");
        retirar();
        if(retiro <= getSaldo()){
            movimientos = getSaldo();
            temp = movimientos - retiro;
            setSaldo(temp);
            System.out.println("***********************************");
            System.out.println("Usted retiro: "+ "$"+retiro+" pesos.");
            System.out.println("Su saldo actual es: "+ "$"+getSaldo()+" pesos.");
            System.out.println("***********************************");
            retiros+=1;
            CAPadre cp = new CDonaciones();
            cp.movimiento();
        }else{
            System.out.println("****************************************");
            System.out.println("No tiene suficiente saldo para retirar");
            System.out.println("****************************************");
        }
    }
    
    public int getRetiros(){
        return retiros;
    }
    
}
