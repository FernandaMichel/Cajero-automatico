package upv.edu.mx;

public class CRecargas extends CAPadre {

    @Override
    public void movimiento() {
        int comp = 0;
        String telefono;
        int recarga = 0;
        boolean ban = false;
        boolean ban2 = false;
        int op = 0;
        int temp = 0;
        int saldo1 = 50;
        int saldo2 = 100;
        int saldo3 = 200;
        int saldo4 = 500;

        System.out.println("Ingrese el numero de telefono: ");
        telefono = sc.nextLine();

        do {
            System.out.println("Seleccione la compañia: ");
            System.out.println("    1. Telcel");
            System.out.println("    2. Movistar");
            System.out.println("    3. AT&T");

            comp = sc.nextInt();

            if (comp >= 1 && comp <= 3) {
                ban = true;
            } else {
                System.out.println("************************************");
                System.out.println("Opcion inválida, intentelo de nuevo");
                System.out.println("************************************");
            }

            if (comp == 1) {
                System.out.println("******************************");
                System.out.println("Compañia seleccionada: Telcel");
                System.out.println("******************************");
            } else if (comp == 2) {
                System.out.println("*******************************");
                System.out.println("Compañia seleccionada: Movistar");
                System.out.println("*******************************");
            } else if (comp == 3) {
                System.out.println("******************************");
                System.out.println("Compañia seleccionada: AT&T");
                System.out.println("******************************");
            }
        } while (ban == false);

        do {
            System.out.println("Seleccione el monto de la recarga: ");
            System.out.println("    1. 50 pesos ");
            System.out.println("    2. 100 pesos ");
            System.out.println("    3. 200 pesos ");
            System.out.println("    4. 500 pesos ");
            op = sc.nextInt();

            if (op >= 1 && op <= 4) {
                ban2 = true;
            } else {
                System.out.println("************************************");
                System.out.println("Opcion inválida, intentelo de nuevo");
                System.out.println("************************************");
            }
            
            if(op == 1){
                recarga = saldo1;
            }
            else if(op == 2){
                recarga = saldo2;
            }
            else if(op == 3){
                recarga = saldo3;
            }
            else if(op == 4){
                recarga = saldo4;
            }

            if (recarga <= getSaldo()) {
                if (op == 1) {
                    System.out.println("**************************************************");
                    System.out.println("Recarga realizada con éxito");
                    movimientos = getSaldo();
                    temp = movimientos - saldo1;
                    setSaldo(temp);
                    System.out.println("Su saldo actual es de: " + "$" + getSaldo() + " pesos.");
                    System.out.println("**************************************************");
                    CAPadre cp = new CDonaciones();
                    cp.movimiento();
                } else if (op == 2) {
                    System.out.println("**************************************************");
                    System.out.println("Recarga realizada con éxito");
                    movimientos = getSaldo();
                    temp = movimientos - saldo2;
                    setSaldo(temp);
                    System.out.println("Su saldo actual es de: " + "$" + getSaldo() + " pesos.");
                    System.out.println("**************************************************");
                    CAPadre cp = new CDonaciones();
                    cp.movimiento();
                } else if (op == 3) {
                    System.out.println("**************************************************");
                    System.out.println("Recarga realizada con éxito");
                    movimientos = getSaldo();
                    temp = movimientos - saldo3;
                    setSaldo(temp);
                    System.out.println("Su saldo actual es de: " + "$" + getSaldo() + " pesos.");
                    System.out.println("**************************************************");
                    CAPadre cp = new CDonaciones();
                    cp.movimiento();
                } else if (op == 4) {
                    System.out.println("**************************************************");
                    System.out.println("Recarga realizada con éxito");
                    movimientos = getSaldo();
                    temp = movimientos - saldo4;
                    setSaldo(temp);
                    System.out.println("Su saldo actual es de: " + "$" + getSaldo() + " pesos.");
                    System.out.println("**************************************************");
                    CAPadre cp = new CDonaciones();
                    cp.movimiento();
                } else {
                    //Muestra de nuevo el menu
                }
            }else{
                System.out.println("****************************************");
                System.out.println("No tiene suficiente saldo para recargar");
                System.out.println("****************************************");
            }

        } while (ban2 == false);
    }

}
