
package upv.edu.mx;


public class CTransferencias extends CAPadre{

    private static int transferencias;
    
    @Override
    public void movimiento() 
    {
        int temp = 0;
        String clabe;
        
        
        
        System.out.println("Ingrese la CLABE INTERBANCARIA del cliente al que se le realizará la transferencia:");
        clabe = sc.nextLine();
        
        System.out.print("¿Cuanto desea transferir?: ");
        transferir();
        
        if(transferencia <= getSaldo()){
            movimientos = getSaldo();
            temp = movimientos - transferencia;
            setSaldo(temp);
            System.out.println("***********************************");
            System.out.println("Usted hizo una trasferencia de "+ "$"+transferencia+" pesos al usuario con la CLABE INTERBANCARIA: "+clabe);
            System.out.println("Su saldo actual es: "+ "$"+getSaldo()+" pesos.");
            System.out.println("***********************************");
            transferencias+=1;
            CAPadre cp = new CDonaciones();
            cp.movimiento();
        }else{
            System.out.println("****************************************");
            System.out.println("No tiene suficiente saldo para transferir");
            System.out.println("****************************************");
        }
    }
    
    public int getTransferencias(){
        return transferencias;
    }
    
}
