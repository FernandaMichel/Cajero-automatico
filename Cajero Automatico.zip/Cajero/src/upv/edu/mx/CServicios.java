
package upv.edu.mx;

public class CServicios extends CAPadre {

    private static int servicios;
    @Override
    public void movimiento() 
    {
        boolean ban = false;
        servicios+=1;
        do{
        System.out.println("Seleccione el servicio: ");      
        System.out.println("    1. Recarga móvil");
        System.out.println("    2. Pago de agua");
        System.out.println("    3. Pago de luz");
        System.out.println("    4. Pago de internet");
        servir();
        
        if(servicio >=1 && servicio<=4){
            ban = true;
        }else{
            System.out.println("************************************");
            System.out.println("Opcion inválida, intentelo de nuevo");
            System.out.println("************************************");
        }
        
        if(servicio == 1){
            CAPadre cp = new CRecargas();
            cp.movimiento();
        }else if(servicio == 2){
            CAPadre cp = new CPagosAgua();
            cp.movimiento();
        }else if(servicio == 3){
            CAPadre cp = new CPagosLuz();
            cp.movimiento();  
        }else if(servicio == 4){
            CAPadre cp = new CPagosInternet();
            cp.movimiento();  
        }
        
        }while(ban == false);
         
    }
    
    public int getServicios(){
        return servicios;
    }
    
}
