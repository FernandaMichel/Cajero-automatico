package upv.edu.mx;

import java.util.Scanner;

public abstract class CAPadre {

    protected int deposito;// este metodo es el que permite almacenar el valor ingresado por teclado
    protected int movimientos;//aydua a obtener el saldo 
    protected int retiro; // 
    protected int servicio;
    protected int transferencia;
    private static int saldo = 3000;

    Scanner sc = new Scanner(System.in);

    public void operaciones() {
        boolean ban = false;
        int op = 0;
        int op2 = 0;
        do {
            do {

                System.out.println("********** Menú Principal **********");
                System.out.println("    1. Consultar saldo y movimientos");
                System.out.println("    2. Retirar efectivo");
                System.out.println("    3. Depositar efectivo");
                System.out.println("    4. Servicios");
                System.out.println("    5. Transferencias");
                System.out.println("    6. Salir");
                System.out.print("Seleccione una opcion: ");
                op = sc.nextInt();

                if (op >= 1 && op <= 6) {
                    ban = true;
                } else {
                    System.out.println("************************************");
                    System.out.println("Opcion inválida, intentelo de nuevo");
                    System.out.println("************************************");
                }
            } while (ban == false);

            if (op == 1) {
                CAPadre c = new CConsultas();
                c.movimiento();
            } else if (op == 2) {
                CAPadre c = new CRetiros();
                c.movimiento();
            } else if (op == 3) {
                CAPadre c = new CDepositos();
                c.movimiento();
            } else if (op == 4) {
                CAPadre c = new CServicios();
                c.movimiento();
            } else if (op == 5) {
                CAPadre c = new CTransferencias();
                c.movimiento();
            } else if (op == 6) {
                System.out.println("¿Desea salir? 1. Si   ||   2. No");
                op2 = sc.nextInt();
                if (op2 == 1) {
                    System.out.println("***************");
                    System.out.println("Hasta pronto!");
                    System.out.println("***************");
                    System.exit(0);
                } else {
                    //Vuelve a mostrar el menú porque sigue el while
                }

            }

        } while (op2 != 1);
    }

    public void retirar() {
        retiro = sc.nextInt();
    }

    public void depositar() {
        deposito = sc.nextInt();
    }
    
    public void servir()
    {
        servicio = sc.nextInt();
    }
    
    public void transferir()
    {
        transferencia = sc.nextInt();
    }
    

    public abstract void movimiento();

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

}
