package upv.edu.mx;

public class CDonaciones extends CAPadre {

    private static int donaciones;

    @Override
    public void movimiento() {
        int op = 0;
        int temp = 0;
        int donacion = 5;
        boolean ban = false;

        do {
            System.out.println("¿Deseas donar $5 pesos para BECALOS?  1. Si    ||   2. NO");
            op = sc.nextInt();

            if (op >= 1 && op <= 2) {
                ban = true;
            } else {
                System.out.println("************************************");
                System.out.println("Opcion inválida, intentelo de nuevo");
                System.out.println("************************************");
            }

            if (5 <= getSaldo()) {
                if (op == 1) {
                    donaciones += 1;
                    movimientos = getSaldo();
                    temp = movimientos - donacion;
                    setSaldo(temp);
                    System.out.println("*************************************************");
                    System.out.println("Donación realizada con exito!");
                    System.out.println("Su saldo actual es de: " + "$" + getSaldo() + " pesos.");
                    System.out.println("*************************************************");
                } else {
                    //Se regresa al menu
                }
            }else
            {
                System.out.println("****************************************");
                System.out.println("No tiene suficiente saldo para donar");
                System.out.println("****************************************");
            }

        } while (ban == false);
    }

    public int getDonaciones() {
        return donaciones;
    }

}
