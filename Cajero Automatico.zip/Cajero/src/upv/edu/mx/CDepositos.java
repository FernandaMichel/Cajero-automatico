
package upv.edu.mx;

public class CDepositos extends CAPadre{

    private static int depositos = 0;
    
    @Override
    public void movimiento() {
        int temp = 0;
        
        depositos+=1;
        System.out.println("¿Cuanto saldo desea depositar?: ");
        depositar();
        
        movimientos = getSaldo();
        temp = movimientos + deposito;
        setSaldo(temp);
        
        System.out.println("*****************************************");
        System.out.println("Usted depositó: "+ "$"+deposito+" pesos.");
        System.out.println("Su saldo actual es: "+ "$"+getSaldo()+ " pesos.");
        System.out.println("*****************************************");
        CAPadre cp = new CDonaciones();
        cp.movimiento();
        
    }
    
    public int getDepositos(){
        return depositos;
    }
}
