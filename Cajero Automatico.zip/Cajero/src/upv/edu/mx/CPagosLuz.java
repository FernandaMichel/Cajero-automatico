package upv.edu.mx;

public class CPagosLuz extends CAPadre {

    @Override
    public void movimiento() {
        String numServ;
        int op = 0;
        int temp = 0;
        int pago = 600;
        int disp = 0;
        boolean ban = false;

        System.out.println("Ingrese su numero de servicio: ");
        numServ = sc.nextLine();

        do {
            System.out.println("Usted debe $600 pesos, ¿Desea pagar?   1. Si     ||    2. No");
            op = sc.nextInt();

            if (op >= 1 && op <= 2) {
                ban = true;
            } else {
                System.out.println("************************************");
                System.out.println("Opcion inválida, intentelo de nuevo");
                System.out.println("************************************");
            }

            if (op == 1) {
                disp = pago;
            }

            if (disp <= getSaldo()) {
                if (op == 1) {
                    movimientos = getSaldo();
                    temp = movimientos - pago;
                    setSaldo(temp);
                    System.out.println("****************************************************");
                    System.out.println("Pago realizado con éxito");
                    System.out.println("Su saldo actual es de: " + "$" + getSaldo() + " pesos.");
                    System.out.println("****************************************************");
                    CAPadre cp = new CDonaciones();
                    cp.movimiento();
                } else {
                    //Se va al menu
                }
            }else{
                System.out.println("****************************************");
                System.out.println("No tiene suficiente saldo para pagar");
                System.out.println("****************************************");
            }

        } while (ban == false);
    }

}
